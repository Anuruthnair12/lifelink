from flask import Flask, render_template, request, redirect, session
from datetime import timedelta
import pymongo
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.permanent_session_lifetime = timedelta(days=7)

# Database configuration
mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
db = mongo_client["lifelink"]
users_collection = db["users"]

@app.route('/')
def home():
    if 'email' in session:
        return render_template('home.html', email=session['email'])
    return redirect('/login')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        changepassword = request.form['changepassword']

        user = {
            "email": email,
            "password": password,
            "changepassword": changepassword
        }

        try:
            users_collection.insert_one(user)
            return redirect('/login')
        except pymongo.errors.DuplicateKeyError:
            return render_template('register.html', message='Email already registered. Please try again.')

    return render_template('register.html', message=None)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = users_collection.find_one({"email": email, "password": password})

        if user:
            session['email'] = email
            return redirect('/')
        else:
            return render_template('login.html', message='Invalid email or password')

    return render_template('login.html', message=None)

@app.route('/profile')
def profile():
    return render_template('profile.html')

if __name__ == '__main__':
    app.run(debug=True)
